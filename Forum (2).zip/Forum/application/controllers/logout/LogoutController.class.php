<?php

session_destroy();

$http= new Http();
$http->redirectTo('/');

 ?>
