<?php
class LoginController {

  public function httpGetMethod(Http $http, array $queryFields)
  {


  }

  public function httpPostMethod(Http $http, array $formFields)
  {
    $conex = new RegisterModel();
    $user = $conex->log($_POST['email']);



   $conex->verif($_POST['password'], $user);


  }

}





 ?>
