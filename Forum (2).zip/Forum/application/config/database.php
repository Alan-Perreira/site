<?php

/*
 * Database configuration settings used by PDO.
 */

 $config['dsn']      = 'mysql:host=localhost;dbname=projet';
 $config['password'] = 'root';
 $config['user']     = 'root';
